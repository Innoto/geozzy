<?php
/*
  Normas de estilo:

  Valores:
  - Las rutas NO finalizan en /
*/


//
// Framework Path
//
define( 'COGUMELO_LOCATION', '/home/proxectos/cogumelo' );
define( 'COGUMELO_DIST_LOCATION', '/home/proxectos/geozzy');

