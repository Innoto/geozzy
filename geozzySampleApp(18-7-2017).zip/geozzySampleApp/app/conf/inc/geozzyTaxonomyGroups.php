<?php

global $GEOZZY_TAXONOMYGROUPS;
$GEOZZY_TAXONOMYGROUPS = array();

/*
$GEOZZY_TAXONOMYGROUPS['taxPruebaParaTematica'] = array(
  'idName' => 'taxPruebaParaTematica',
  'name' => array(
    'es' => 'Test taxonomy',
    'en' => 'Test taxonomy',
    'gl' => 'Test taxonomy'
  ),
  'editable' => 0,
  'nestable' => 1,
  'sortable' => 1,
  'initialTerms' => array(
    array(
      'idName' => 'pruebaTaxTerm1',
      'name' => array(
        'en'=>'Term creation test 1',
        'es'=>'Prueba creacion de termino 1',
        'gl'=>'Proba creacion de termo 1'
      )
    ),
    array(
      'idName' => 'pruebaTaxTerm2',
      'name' => array(
        'en'=>'Term creation test 2' ,
        'es'=>'Prueba creacion de termino 2',
        'gl'=>'Proba creacion de termo 2'
      )
    ),
    array(
      'idName' => 'pruebaTaxTerm3',
      'name' => array(
        'en'=>'Term creation test 3',
        'es'=>'Prueba creacion de termino 3',
        'gl'=>'Proba creacion de termo 3'
      )
    )
  )
);
*/
