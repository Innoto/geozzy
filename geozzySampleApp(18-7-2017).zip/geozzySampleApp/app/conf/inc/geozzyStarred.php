<?php

global $GEOZZY_STARRED;

/**
 * Declaramos los terminos de la taxonomia Starred
 */
/*
$GEOZZY_STARRED['destacadoTerm'] = array(
  'idName' => 'destacadoTerm',
  'name' => array(
    'es' => 'destacadoTerm name'
  )
);
*/
