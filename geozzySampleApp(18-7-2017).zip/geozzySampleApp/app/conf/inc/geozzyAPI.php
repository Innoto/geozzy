<?php
define( 'GEOZZY_API_ACTIVE', true);

geozzyAPI::addModuleAPI( 'admin' );
geozzyAPI::addModuleAPI( 'geozzy' );
//geozzyAPI::addModuleAPI( 'explorer' );
//geozzyAPI::addModuleAPI( 'rextCommunity' );
//geozzyAPI::addModuleAPI( 'rextFavourite' );
//geozzyAPI::addModuleAPI( 'rextTravelPlanner' );
//geozzyAPI::addModuleAPI( 'rextComment' );
//geozzyAPI::addModuleAPI( 'rextRoutes' );
//geozzyAPI::addModuleAPI( 'story' );
