$( document ).ready(function(){
  $(function () {
    $('[data-toggle="tooltip"]').tooltip()
  })
});
