
$( document ).ready( function() {

  $( '.headContent .navbar' ).css( 'background-color', '#ffAAAA' );
  alert( 'IMPORTANTE: Este recurso NO es visible!!!' );

});
