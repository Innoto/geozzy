phpdoc run -d . -t phpdoc/ --cache-folder phpdoc/cache/ --ignore 'phpdoc/,*/tmp/,*/httpdocs/'
